package ca.mcgill.ecse321.FTMS.application;

import ca.mcgill.ecse321.FTMS.persistence.PersistenceFTMSInventory;
import ca.mcgill.ecse321.FTMS.persistence.PersistenceFTMSMenu;
import ca.mcgill.ecse321.FTMS.persistence.PersistenceFTMSSchedule;
import ca.mcgill.ecse321.FTMS.view.FTMSPage;

public class FTMS {
		public static void main(String[] args) {
			//load model
			PersistenceFTMSSchedule.loadFTMSScheduleModel();
			PersistenceFTMSInventory.loadFTMSInventoryModel();
			PersistenceFTMSMenu.loadFTMSMenuModel();
			
			// start UI
			java.awt.EventQueue.invokeLater(new Runnable(){
				public void run(){
					new FTMSPage().setVisible(true);
					
				}
			});

		}

	}
