package ca.mcgill.ecse321.FTMS.persistence;

import java.util.Iterator;

import ca.mcgill.ecse321.FTMS.model.Menu;
import ca.mcgill.ecse321.FTMS.model.OrderManager;


public class PersistenceFTMSMenu {
	private static String filename = "FTMSMANAGER.xml";

	public static void setFilename(String fn) {
		filename = fn;
	}
	
	private static void initializeXStream(){
		PersistenceXStreamSchedule.setFilename(filename +"Menu.xml");
		PersistenceXStreamSchedule.setAlias("menu", Menu.class);
		PersistenceXStreamSchedule.setAlias("manager", OrderManager.class);
		
	}

	public static void loadFTMSMenuModel() {
		OrderManager om = OrderManager.getInstance();
		PersistenceFTMSMenu.initializeXStream();
		OrderManager om2 = (OrderManager)PersistenceXStreamMenu.loadFromXMLwithXStream();
		if(om2 != null){
			// unfortunately, this creates a second RegistrationManager object, even though its singleton
			//copy loaded model into singleton instance of RegistrationManager, because this will be used throughout the application
			Iterator<Menu> fIt = om2.getMenus().iterator();
			while(fIt.hasNext())
				om.addMenus(fIt.next());
			}
		
	}


}
