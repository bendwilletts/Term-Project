package ca.mcgill.ecse321.FTMS.persistence;

import java.util.Iterator;


import ca.mcgill.ecse321.FTMS.model.Equipment;
import ca.mcgill.ecse321.FTMS.model.OrderManager;

import ca.mcgill.ecse321.FTMS.model.Supply;



public class PersistenceFTMSInventory {	
	private static String filename = "FTMSMANAGER";

	public static void setFilename(String fn) {
		filename = fn;
	}
	
	private static void initializeXStream(){
		PersistenceXStreamSchedule.setFilename(filename +"Inventory.xml");
		PersistenceXStreamSchedule.setAlias("equipment", Equipment.class);
		PersistenceXStreamSchedule.setAlias("supply", Supply.class);
		PersistenceXStreamSchedule.setAlias("manager", OrderManager.class);
		
	}

	public static void loadFTMSInventoryModel() {
		OrderManager om = OrderManager.getInstance();
		PersistenceFTMSInventory.initializeXStream();
		OrderManager om2 = (OrderManager)PersistenceXStreamInventory.loadFromXMLwithXStream();
		if(om2 != null){
			// unfortunately, this creates a second RegistrationManager object, even though its singleton
			//copy loaded model into singleton instance of RegistrationManager, because this will be used throughout the application
			Iterator<Supply> fIt = om2.getFoodSupplies().iterator();
			while(fIt.hasNext())
				om.addFoodSupply(fIt.next());
			Iterator<Equipment> eIt = om2.getEquipments().iterator();
			while(eIt.hasNext())
				om.addEquipment(eIt.next());
			}
		
	}

}
